# Persona Interview - Full Question Bank

Ask these one at a time or in small clusters. Adapt based on what's relevant for the product.

## Demographics & Role

1. What should we name this persona? (Use a realistic first name - Sarah, Mike, David - not "Admin Andy")
2. What's their job title? What do they actually do day-to-day - not the job description, the reality?
3. What kind of organization do they work in? Size? Type? (e.g., "mid-size church, 500-1000 members, 3 full-time staff")
4. Who do they report to? Who reports to them?
5. How comfortable are they with technology on a 1-5 scale? (1 = "calls their kid to set up their phone," 5 = "could build a website themselves")
6. What age range? What career stage? (early career still figuring it out, mid-career experienced, senior/veteran, approaching retirement)
7. What's their educational background? (not for judgment - for understanding communication style and expectations)
8. How long have they typically been in this role?

## Goals & Motivations

9. What's the job to be done? When this person opens the product, what are they trying to accomplish?
10. What does personal success look like for them? (not org success - what makes THEM feel good about their work)
11. What are they measured on? What makes their boss say "great job"?
12. What would make them recommend this product to a peer unprompted?
13. What's the dream scenario - if the product worked perfectly, what would their experience be?

## Frustrations & Pain Points

14. What frustrates them most about the current product experience?
15. What workarounds have they built? (spreadsheets on the side, sticky notes, manual processes that should be automated)
16. What tasks do they put off or dread?
17. What would they change if they had a magic wand?
18. Have they ever considered switching to something else? What triggered that thought?
19. What do they complain about to their colleagues?

## Behavior & Workflow

20. How often do they use the product? (multiple times daily, daily, weekly, monthly, seasonally, event-driven)
21. What's a typical session look like? How long? What do they do in order?
22. What triggers them to open the product? (a specific need, a scheduled task, a notification, a request from someone)
23. What other tools do they use before, during, or after using this product?
24. How did they learn to use the product? (formal training, self-taught, peer showed them, trial and error)
25. Do they use the product directly or through an integration embedded in another system?
26. Do they use the mobile experience or only desktop?
27. What percentage of the product's features do they actually use? (power user using everything, or focused on 2-3 things)

## Decision-Making & Influence

28. Did they choose this product, or was it chosen for them? By whom?
29. Do they have the power to switch products? Or is that someone else's decision?
30. What would make them push to switch to a competitor?
31. Where do they get recommendations for tools? (peers, consultants, conferences, Facebook groups, denominational networks)
32. How do they evaluate whether a tool is working? (gut feeling, metrics, feedback from others, cost)

## Context & Environment

33. Where are they physically when they use the product? (office, home, on-site at an event, moving between rooms)
34. What's the vibe when they're using it? (calm desk work, hectic event setup, between meetings, multitasking with a kid in the room)
35. Are there seasonal patterns? (busy before Easter, summer camps, fall kickoff, year-end giving)
36. Are there time-of-day patterns? (morning admin, late-night catch-up, during-event quick checks)

## Emotional & Social

37. How do they feel about the product emotionally? (love it, tolerate it, resent it, anxious about it)
38. Is there any status or identity tied to using this product? (e.g., "I'm the one who handles all the background checks")
39. Do they interact with other users of the product? How?
40. What's their relationship with the vendor/company behind the product?

## Summary & Voice

41. If this person were describing their experience with the product to a friend over coffee, what would they say? (capture in their voice, not corporate language)
42. What's the one sentence that captures their relationship with the product?
43. What's their biggest unspoken need - the thing they want but wouldn't know how to ask for?
