# Persona Document - Output Template

Each persona is a self-contained markdown document ready for Confluence.

---

## Template

```markdown
# [Persona Name] - [Tier: Primary / Secondary / Tertiary] Persona

**[Product Name]** | Created [Date] | Last Updated [Date]

---

## At a Glance

| | |
|---|---|
| **Name** | [First name] |
| **Role** | [Job title] |
| **Organization** | [Type and size - e.g., "Mid-size church, 500-1000 members, 3 full-time staff"] |
| **Age Range** | [e.g., 35-50] |
| **Tech Comfort** | [1-5 scale with label - e.g., "3/5 - Comfortable with standard tools, hesitant with new systems"] |
| **Product Usage** | [Frequency - e.g., "Weekly, typically Monday mornings, 15-30 min sessions"] |
| **Tier** | [Primary / Secondary / Tertiary] |

**Photo:** [Unsplash URL - include a direct link to a portrait matching this persona's demographics]

---

## The Quote

> "[A single sentence in this persona's voice that captures their relationship with the product]"

---

## Who They Are

[2-3 paragraphs in narrative form. Paint a picture of this person's daily reality - not just their job description, but what their day actually looks like. What's on their desk, who's knocking on their door, what's on their mind. This should read like a character description, not a data sheet.]

---

## Goals & Motivations

### Primary Goal
[The main job to be done - why they open the product]

### What Success Looks Like
[What makes them feel good about their work - personal success, not org metrics]

### What They're Measured On
[What their boss cares about - the external success criteria]

### Dream Scenario
[If everything worked perfectly, what would their experience be]

---

## Frustrations & Pain Points

### Top Frustrations
1. [Frustration 1 - specific and concrete]
2. [Frustration 2]
3. [Frustration 3]

### Workarounds They've Built
[What manual processes, spreadsheets, or hacks have they created to fill gaps in the product]

### What They'd Change
[The magic-wand answer - what they'd fix first if they could]

---

## Behavior & Workflow

### Typical Session
[Walk through what a typical product session looks like for this person - what triggers it, what they do first, how long it takes, what they do after]

### Usage Pattern
- **Frequency:** [daily / weekly / monthly / seasonal / event-driven]
- **Duration:** [typical session length]
- **Trigger:** [what makes them open the product]
- **Device:** [desktop / mobile / tablet / integration]

### Feature Usage
[Which parts of the product they actually use vs. ignore. Power user or focused on 2-3 things?]

### Tool Ecosystem
[What other tools they use alongside this product - this reveals integration opportunities and context]

---

## Decision-Making

### Product Choice
[Did they choose this product? Who decided? Do they have power to switch?]

### Switching Triggers
[What would push them to look at alternatives]

### Information Sources
[Where they get recommendations - peers, consultants, conferences, online communities]

---

## Context

### Physical Environment
[Where they are when using the product]

### Emotional State
[How they feel when using it - calm, rushed, anxious, empowered]

### Seasonal Patterns
[Any cyclical usage patterns - busy seasons, annual events, etc.]

---

## Data Confidence

This section is honest about what's validated vs. assumed.

### Validated (based on data or direct observation)
- [Attribute 1 - source: support tickets, analytics, interviews, etc.]
- [Attribute 2 - source]

### Informed Assumptions (based on product owner experience)
- [Attribute 1 - why we believe this]
- [Attribute 2 - why we believe this]

### Gaps (needs validation)
- [Attribute 1 - what we're guessing and why it matters]
- [Attribute 2 - what we're guessing and why it matters]

*See the Data Validation Guide for a concrete plan to close these gaps.*
```

---

## Style Notes

- Write the persona in third person but make it feel human, not clinical.
- Use specific details, not vague generalizations. "Checks the dashboard every Monday morning before staff meeting" is better than "uses the product regularly."
- The quote should sound like something a real person would say, not a marketing tagline.
- Be honest in the Data Confidence section. Flagging assumptions is a feature, not a weakness.
- Keep it scannable - someone should get the gist in 30 seconds by reading the Quote, At a Glance, and Goals sections.
