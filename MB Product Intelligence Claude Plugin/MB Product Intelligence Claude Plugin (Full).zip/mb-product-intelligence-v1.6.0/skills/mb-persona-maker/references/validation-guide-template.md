# Data Validation Guide - Output Template

This guide is produced alongside the personas. Its purpose is to give the user a concrete, actionable plan for closing every data gap identified in the persona gap analysis. The guide should be practical enough that someone with no UX research experience can follow it.

---

## Template

```markdown
# Data Validation Guide - [Product Name] Personas

**Purpose:** This guide identifies assumptions in your user personas and gives you a step-by-step plan to validate or correct each one. As you gather data, format your findings using the template at the end of this document - then bring them back and we'll update the personas together.

**Estimated total effort:** [X hours/days across all validation activities]

---

## Validation Priority

Not all gaps are equal. Focus on the ones that influence real decisions.

### High Priority (validate first)
These assumptions directly affect feature prioritization, UX decisions, or go-to-market strategy.

[List the most critical gaps here]

### Medium Priority
These assumptions matter but won't derail decisions if slightly wrong.

[List medium-priority gaps]

### Low Priority (validate when convenient)
Nice to confirm but not urgent.

[List lower-priority gaps]

---

## Validation Plans

### Gap 1: [Assumption being validated]

**What we assumed:** [State the assumption clearly]

**Which persona(s):** [Which persona this affects]

**Why it matters:** [What decisions depend on this being right. What happens if it's wrong.]

**Validation method:** [Choose the most appropriate]:

#### Option A: User Interviews
- **Who to recruit:** [N] people matching [criteria]. Find them through [channel - CS team intros, community posts, existing customer list, etc.]
- **Format:** [Duration] conversation, [in-person / video / phone]. Ask for permission to record.
- **Questions to ask:**
  1. [Specific question - not generic, tailored to this gap]
  2. [Follow-up question]
  3. [Probing question for depth]
- **What to listen for:** [Specific signals that confirm or deny the assumption]
- **Red flags:** [Answers that would mean the assumption is wrong]

#### Option B: Analytics / Data Pull
- **What to look for:** [Specific metric, pattern, or data point]
- **Where to find it:** [Tool, dashboard, database, or report]
- **What pattern confirms the assumption:** [Description]
- **What pattern contradicts it:** [Description]

#### Option C: Support Ticket Analysis
- **Search for:** [Keywords, ticket categories, or themes]
- **Sample size:** Review at least [N] tickets
- **What to look for:** [Patterns that reveal user behavior or needs]

#### Option D: Survey
- **When to use:** When you need a larger sample than interviews but the question is straightforward
- **Questions:** [2-5 specific survey questions - keep it short]
- **Distribution:** [How to send it - email list, in-app, CS team distribution]
- **Minimum responses:** [N] for meaningful signal

#### Option E: Observation
- **When to use:** When you need to see behavior, not hear about it (people often describe their behavior differently than they actually behave)
- **What to observe:** [Specific interaction, workflow, or scenario]
- **How:** [Screen share session, in-person shadowing, session recording tool]

**Time estimate:** [How long this validation takes - hours, days]

---

[Repeat for each gap...]

---

## Interview Guides

### Interview Guide: [Research Goal]

**Goal:** Answer the question: [What specific thing we're trying to learn]

**Participants:** [N] people. Recruit from [source]. Criteria: [who qualifies]

**Format:** [Duration] minutes, [video/phone/in-person]. Record with permission.

**Warm-up (2-3 min)**
- Thanks for taking the time. I'm trying to understand how people like you use [product area] so we can make it better.
- There are no right or wrong answers - I'm here to learn from your experience.
- Is it OK if I record this so I don't miss anything? It's only for internal use.

**Context Questions (5 min)**
1. Tell me about your role. What does a typical week look like for you?
2. How long have you been using [product]?
3. How did you first start using it?

**Core Questions (15-20 min)**
[These are specific to the research goal - provided per gap]

4. [Question targeting the specific assumption]
5. [Follow-up for depth]
6. [Question from a different angle to triangulate]
7. [Scenario-based question: "Walk me through the last time you..."]
8. [Comparison question: "Before you had this, how did you handle..."]

**Probing Prompts** (use throughout):
- "Can you tell me more about that?"
- "What happened next?"
- "How did that make you feel?"
- "Why do you think that is?"
- "Can you give me a specific example?"

**Wrap-up (3 min)**
9. If you could change one thing about [product/feature], what would it be?
10. Is there anything I didn't ask about that you think is important for us to know?
11. Would you be open to a follow-up conversation if we have more questions?

**After the Interview:**
- Write up notes within 24 hours (memory fades fast)
- Note specific quotes that were revealing
- Tag each finding with which persona and which assumption it relates to
- Use the findings template below

---

## How to Capture & Format Findings

As you gather data, use this format so the information is easy to feed back into persona updates:

### Finding Template

For each thing you learn:

| Field | Value |
|-------|-------|
| **Source** | [Interview / Analytics / Support tickets / Survey / Observation] |
| **Date** | [When you gathered this] |
| **Participant** | [Anonymized - e.g., "Volunteer coordinator, large church"] |
| **Which persona** | [Name of the persona this affects] |
| **Which assumption** | [The assumption this validates or changes] |
| **What we learned** | [Describe the finding in 2-3 sentences] |
| **Direct quote** | [If from an interview, capture a key quote] |
| **Validates or changes?** | [Does this confirm the assumption or suggest it needs updating?] |
| **Updated understanding** | [If it changes the assumption, what should the persona say instead?] |

### Batch Handoff

When you've gathered a set of findings (even partial - don't wait for everything), compile them and bring them back to Claude with a prompt like:

> "I've been validating our personas for [product]. Here are my findings - can you update the personas based on this data?"

Attach or paste the findings. Claude will update the persona documents, move attributes from "Assumed" to "Validated" in the confidence section, and flag any new questions that emerged from the research.
```

---

## Guide Writing Notes

- Be specific. "Talk to users" is useless. "Interview 5 volunteer coordinators from churches with 200+ members, found through CS team introductions" is actionable.
- Match the method to the gap. Don't suggest interviews when analytics would answer the question faster. Don't suggest surveys when the topic needs depth.
- Keep interview guides conversational. The user might never have done user research before - the guide should feel approachable, not academic.
- Always include the "findings template" section. The whole point is creating a loop where data flows back into better personas.
- Time estimates matter. A busy PM needs to know this is "2 hours of interviews" not an open-ended research project.
