# Interactive User Flow Map - Design Guide

This reference describes how to build the interactive HTML flow map deliverable.

## File Structure

Single-file HTML with inline CSS and JS. Only external dependency allowed: Google Fonts. The file should work when opened directly in a browser - no build step, no server.

## Visual Design

### Default Brand

If the product has brand colors, use them. Otherwise use this neutral default:
- Primary: `#1B3A6B` (dark navy)
- Font: `Red Hat Text` from Google Fonts (fallback: system sans-serif)
- Background: `#f8f9fa`
- Card background: `#ffffff`
- Border color: `#e0e0e0`
- Border radius: 8-10px for cards

### Badge System

Pain points and improvements are shown as pill-shaped badges attached to flow steps:

**Pain Point Badges:**
- Background: `#fff3e0` (light orange) or `#ffebee` (light red)
- Text: `#e65100` (orange) or `#c62828` (red)
- Icon: Warning triangle or exclamation
- Format: "[icon] Short description"

**Improvement Badges:**
- Background: `#e8f5e9` (light green)
- Text: `#2e7d32` (green)  
- Icon: Checkmark
- Format: "[icon] Short description"

### Flow Diagram Layout

Each flow is a horizontal sequence of connected step cards:

```
[Step 1] ──→ [Step 2] ──→ [Step 3] ──→ [Step 4]
```

Step cards contain:
- Step number (small, top)
- Step title (bold, prominent)
- Brief description (1 line)
- Expand indicator (chevron/arrow)
- Badge container (above the card, for pain points / improvements)

### Expandable Details

Clicking a step card toggles a details panel below it containing:
- Sub-steps or field lists
- Available options/values
- Specific pain points or improvements with full descriptions
- Context about why this step matters

Use smooth CSS transitions for expand/collapse (max-height or similar).

## Page Structure

### Header
- Product name + "User Flows"
- Subtitle with date
- Clean, professional, not flashy

### Tab Navigation (if multiple flow categories)

Common pattern: "Current Flows" | "Improved Flows"

Only include the "Improved Flows" tab if the interview captured enough future-state vision. Don't fabricate improvements - only document what the user described.

### Per-Flow Section

Each flow gets:
1. **Flow title** (with emoji icon if appropriate)
2. **Description** (1-2 sentences of what this flow accomplishes)
3. **Legend** (badge color meanings)
4. **Flow diagram** (the horizontal step sequence)
5. **Summary** (all pain points or improvements listed below the diagram)

### Footer
- Generated date
- "Based on [environment explored] and product owner interview"

## Interactivity

### Required
- Tab switching (if multiple tabs)
- Click-to-expand on step cards
- Keyboard navigation (Enter/Space to toggle steps)

### Nice to Have
- Horizontal drag-to-scroll for wide flow diagrams
- Smooth scroll animations
- Step cards highlight on hover

## Content Guidelines

### Current Flow Steps
Document what actually happens in production today. Be specific about:
- What the user sees (page title, fields, buttons)
- What options are available (dropdown values, toggle states)
- Where decisions happen (which step requires the user to choose something)
- What the commit point is (when does the action become permanent)

### Pain Point Badges
Keep badge text very short (3-5 words). Put the full explanation in the expandable details. Examples:
- "No descriptions" (on a dropdown with opaque options)
- "Misleading label" (on a button that does something unexpected)
- "Wrong commit point" (on a step where the action should happen earlier/later)
- "Missing info" (on a review screen that omits important details)

### Improvement Badges
Same rule - short text on badge, full explanation in details. Examples:
- "Risk-based selection" (replacing jargon with clear descriptions)
- "Context-aware CTA" (button text changes based on prior choices)
- "Link generation = commit" (commit point moved to the right place)

## Responsive Design

Target desktop (1200px+) as primary. The flow diagrams should scroll horizontally on smaller screens rather than wrapping or breaking. Include basic responsive styles so it doesn't look broken on tablet.
